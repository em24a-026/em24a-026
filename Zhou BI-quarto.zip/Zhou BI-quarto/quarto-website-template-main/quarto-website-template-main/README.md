# Quarto Template for the Tutorial

This repository contains the template for the website tutorial at <https://www.marvinschmitt.com/blog/website-tutorial-quarto/>.

<p align="center">
  <img src="img/website_template_screenshot_1.png" width="45%">
&nbsp; &nbsp; &nbsp; &nbsp;
  <img src="img/website_template_screenshot_2.png" width="45%">
<br/><br/>
  <img src="img/website_template_screenshot_3.png" width="45%">
&nbsp; &nbsp; &nbsp; &nbsp;
  <img src="img/website_template_screenshot_4.png" width="45%">
</p>